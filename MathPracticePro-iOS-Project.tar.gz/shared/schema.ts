import { z } from "zod";

export const competitionTypes = [
  "AMC 8",
  "AMC 10",
  "AIME",
  "MathCounts",
  "NLMC",
  "Math Kangaroo"
] as const;

export const topicTypes = [
  "Algebra",
  "Geometry",
  "Number Theory",
  "Combinatorics",
  "Probability"
] as const;           

export const problemRequestSchema = z.object({
  competition: z.enum(competitionTypes),
  topics: z.array(z.enum(topicTypes)).min(1, "Select at least one topic"),
  difficulty: z.number().min(1).max(10),
});

export type ProblemRequest = z.infer<typeof problemRequestSchema>;

export const problemResponseSchema = z.object({
  problem: z.string(),
  answer: z.string(),
  explanation: z.string(),
});

export type ProblemResponse = z.infer<typeof problemResponseSchema>;

export const answerSubmissionSchema = z.object({
  userAnswer: z.string().min(1, "Answer cannot be empty"),
  correctAnswer: z.string(),
});

export type AnswerSubmission = z.infer<typeof answerSubmissionSchema>;
//I am an Ayush who is a router 3000 3000 3000 3000 3000 3000 3000 3000 3000 3000 3000