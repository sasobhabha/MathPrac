# iOS App Build Guide - Math Practice Pro

This guide explains how to build and install the Math Practice Pro iOS app as an IPA file.

## Overview

Your Math Practice Pro web app has been wrapped with **Capacitor**, which allows it to run as a native iOS application. Since Replit runs on Linux and building iOS apps requires macOS, we've set up **GitHub Actions** to build the IPA file automatically in the cloud.

## Quick Start

### Option 1: Build with GitHub Actions (Recommended)

1. **Push your code to GitHub**:
   ```bash
   git init
   git add .
   git commit -m "Add iOS Capacitor support"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```

2. **The IPA will be built automatically**:
   - Go to your GitHub repository
   - Click on "Actions" tab
   - Find the "Build iOS App" workflow
   - Download the IPA from the "Artifacts" section

3. **Install the IPA**:
   - Download the `MathPracticePro-iOS.zip` artifact
   - Extract to get `MathPracticePro.ipa`
   - Install using one of the methods below

### Option 2: Build Locally (Requires Mac)

If you have a Mac computer:

```bash
# 1. Build the web app
npm run build

# 2. Sync to iOS
npx cap sync ios

# 3. Install CocoaPods dependencies
cd ios/App
pod install

# 4. Open in Xcode
npx cap open ios

# 5. Build in Xcode (Cmd+B)
# 6. Archive and export IPA
```

## Installation Methods

### Method 1: TrollStore (iOS 14.0 - 17.0)

**TrollStore** is a permanent app installer that doesn't require re-signing every 7 days.

1. Install TrollStore on your device (see [TrollStore Guide](https://ios.cfw.guide/installing-trollstore/))
2. Transfer `MathPracticePro.ipa` to your iPhone
3. Open the IPA with TrollStore
4. Tap "Install"
5. Done! The app is permanently installed

**Pros**: 
- Permanent installation
- No 7-day expiration
- No computer needed after initial TrollStore setup

**Cons**:
- Only works on iOS 14.0 - 17.0
- Requires jailbreak or exploit for initial TrollStore installation

### Method 2: Sideloadly (All iOS versions)

**Sideloadly** is a free tool for sideloading apps on Windows/Mac.

1. Download [Sideloadly](https://sideloadly.io/)
2. Connect your iPhone to computer
3. Open Sideloadly
4. Drag `MathPracticePro.ipa` into Sideloadly
5. Enter your Apple ID (free account works)
6. Click "Start"
7. Install will complete in ~1 minute

**Pros**:
- Works on all iOS versions
- Free Apple ID works (no $99/year developer account needed)
- Easy to use

**Cons**:
- Apps expire every 7 days (need to re-sideload)
- Limited to 3 apps with free Apple ID

### Method 3: AltStore (All iOS versions)

1. Download [AltStore](https://altstore.io/)
2. Install AltServer on your computer
3. Install AltStore on your iPhone
4. Add `MathPracticePro.ipa` to AltStore
5. Refresh apps weekly

**Pros**:
- Can auto-refresh over WiFi
- Manages app expiration

**Cons**:
- Requires AltServer running on computer for refresh
- 7-day expiration (but can auto-refresh)

### Method 4: Apple Developer Account ($99/year)

If you have a paid Apple Developer account:

1. Open project in Xcode
2. Configure code signing with your developer certificate
3. Archive and export with App Store or Ad Hoc distribution
4. Install via TestFlight or direct installation
5. Apps last 1 year

## App Configuration

### Customizing App Details

Edit `capacitor.config.ts`:

```typescript
const config: CapacitorConfig = {
  appId: 'com.mathpracticepro.app',      // Change to your unique bundle ID
  appName: 'Math Practice Pro',          // Change app name
  webDir: 'dist/public',
  // ... other settings
};
```

### Customizing App Icon

Replace the icon files in:
```
ios/App/App/Assets.xcassets/AppIcon.appiconset/
```

You need these sizes:
- 20x20, 29x29, 40x40, 60x60, 76x76, 83.5x83.5, 1024x1024

Use a tool like [AppIcon.co](https://www.appicon.co/) to generate all sizes from one image.

### Customizing Splash Screen

Replace splash images in:
```
ios/App/App/Assets.xcassets/Splash.imageset/
```

## Cloud Build Services (Alternative to GitHub Actions)

If you need more advanced builds or don't want to use GitHub Actions:

### Codemagic (Recommended)
- **Free tier**: 500 build minutes/month
- **Website**: https://codemagic.io
- **Best for**: Production iOS apps
- **Setup**: Connect GitHub → Configure workflow → Automatic builds

### Bitrise
- **Free tier**: 300 credits/month  
- **Website**: https://bitrise.io
- **Best for**: CI/CD pipelines

### EAS Build (Expo)
- Can also build Capacitor apps
- **Website**: https://expo.dev/eas

## Troubleshooting

### "Could not install app"
- Make sure you trust the developer certificate in Settings > General > VPN & Device Management
- If using free Apple ID, ensure you haven't exceeded 3 app limit

### "App keeps crashing"
- Check the iOS logs in Xcode Console (Window > Devices and Simulators)
- Verify all web assets built correctly (`npm run build`)

### "GitHub Actions build failed"
- Check the Actions logs in your GitHub repository
- Ensure all dependencies are in package.json
- Verify the build command works locally

## Development Workflow

For active development on a Mac:

```bash
# 1. Start dev server
npm run dev

# 2. In another terminal, sync to iOS with live reload
npx cap sync ios
npx cap run ios --livereload --external --address=YOUR_IP

# 3. Make changes - app updates automatically
```

## API Keys and Environment Variables

Your app uses OpenAI API. For the iOS app to work:

1. The API calls need to go through your backend server
2. Make sure your backend is deployed and accessible
3. Update the API endpoint in your frontend code if needed
4. For local testing, use `server.url` in capacitor.config.ts to point to your local server

## Production Deployment

For a production iOS app:

1. Get an Apple Developer account ($99/year)
2. Create App ID and provisioning profiles
3. Configure code signing in Xcode
4. Build with Release configuration
5. Submit to App Store or distribute via TestFlight

## Additional Resources

- [Capacitor Documentation](https://capacitorjs.com/docs)
- [Capacitor iOS Guide](https://capacitorjs.com/docs/ios)
- [TrollStore Installation Guide](https://ios.cfw.guide/installing-trollstore/)
- [Sideloadly Tutorial](https://sideloadly.io/#tutorial)
- [GitHub Actions Documentation](https://docs.github.com/en/actions)

## Support

If you encounter issues:
1. Check the GitHub Actions logs
2. Review Capacitor documentation
3. Test the web app locally first (`npm run dev`)
4. Ensure your backend API is accessible

---

**Note**: The IPA built by GitHub Actions is unsigned and meant for sideloading only. For App Store distribution, you'll need a paid Apple Developer account and proper code signing.
