import type { Express } from "express";
import { createServer, type Server } from "http";
import OpenAI from "openai";
import { problemRequestSchema, problemResponseSchema } from "@shared/schema";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/generate-problem", async (req, res) => {
    try {
      const parseResult = problemRequestSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          error: "Invalid request parameters",
          details: parseResult.error.errors
        });
      }
      
      const { competition, topics, difficulty } = parseResult.data;

      const difficultyGuide = `
Difficulty Scale (1-10):
- 1-2: Elementary level (e.g., "x + 2 = 3", basic arithmetic, simple word problems)
- 3-4: Middle school level (e.g., basic fractions, simple geometry, percentages)
- 5-6: Standard ${competition} competition level
- 7-8: Challenging ${competition} problems
- 9-10: Very difficult problems, near the hardest from ${competition}
`;

      const topicsList = topics.join(", ");

      const systemPrompt = `You are an expert math competition problem generator. Generate problems that match the style and difficulty of real ${competition} competition problems. Draw inspiration from previous ${competition} contests.`;

      const userPrompt = `Generate a single ${competition} math problem with the following specifications:

Competition: ${competition}
Topics: ${topicsList}
Difficulty: ${difficulty}/10

${difficultyGuide}

IMPORTANT FORMATTING REQUIREMENTS:
1. Use LaTeX math notation wrapped in $ for inline math and $$ for display math
2. The problem should be appropriate for ${competition}
3. Include any necessary diagrams or figures as text descriptions if needed
4. Make the problem challenging and interesting, similar to actual ${competition} competition problems

ANSWER FORMAT REQUIREMENTS:
- Provide the answer in the simplest, most standard numerical form
- For fractions: use "a/b" format (e.g., "3/4" not "\\frac{3}{4}")
- For radicals: use "sqrt(n)" format (e.g., "sqrt(2)" not "$\\sqrt{2}$")
- For mixed expressions: use standard math notation (e.g., "2+sqrt(3)")
- For decimals: provide exact form when possible
- For integers: just the number (e.g., "42")
- Multiple acceptable forms can be separated by " or " (e.g., "3/4 or 0.75")
- Do NOT use LaTeX notation in the answer field

Respond in JSON format with exactly these fields:
{
  "problem": "The problem statement with LaTeX math in $ or $$ delimiters",
  "answer": "The answer in simple numerical form (no LaTeX, use a/b for fractions, sqrt(n) for radicals)",
  "explanation": "A clear, step-by-step explanation of how to solve the problem"
}`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.8,
      });

      const responseContent = completion.choices[0]?.message?.content;
      if (!responseContent) {
        throw new Error("No response from AI");
      }

      const parsedResponse = JSON.parse(responseContent);
      const validatedResponse = problemResponseSchema.parse(parsedResponse);

      res.json(validatedResponse);
    } catch (error) {
      console.error("Error generating problem:", error);
      res.status(500).json({ 
        error: "Failed to generate problem",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
