import { evaluate, parse as mathParse } from 'mathjs';

/**
 * Normalizes a math answer string for evaluation.
 */
function normalizeMathExpression(expr: string): string {
  let normalized = expr.trim();
  
  // Convert common notations to mathjs format
  normalized = normalized.replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '($1)/($2)');
  normalized = normalized.replace(/\\sqrt\{([^}]+)\}/g, 'sqrt($1)');
  normalized = normalized.replace(/\\pi/g, 'pi');
  normalized = normalized.replace(/π/g, 'pi');
  
  // Remove LaTeX formatting
  normalized = normalized.replace(/\$+/g, '');
  normalized = normalized.replace(/[\\{}]/g, '');
  
  // Handle mixed numbers (e.g., "1 1/2" -> "1+1/2")
  normalized = normalized.replace(/(\d+)\s+(\d+\/\d+)/g, '$1+$2');
  
  // Handle implicit multiplication (e.g., "2pi" -> "2*pi", "3sqrt(2)" -> "3*sqrt(2)")
  normalized = normalized.replace(/(\d+)(pi|sqrt)/g, '$1*$2');
  normalized = normalized.replace(/(\d+)([a-z])/g, '$1*$2');
  
  return normalized;
}

/**
 * Attempts to evaluate a math expression to a numeric value.
 */
function tryEvaluate(expr: string): number | null {
  try {
    const normalized = normalizeMathExpression(expr);
    const result = evaluate(normalized);
    
    if (typeof result === 'number' && !isNaN(result) && isFinite(result)) {
      return result;
    }
    
    // Handle complex numbers, return null
    return null;
  } catch {
    return null;
  }
}

/**
 * Compares two math answers, handling multiple acceptable formats.
 */
export function compareMathAnswers(userAnswer: string, correctAnswer: string): boolean {
  // Trim both answers
  const userTrimmed = userAnswer.trim();
  const correctTrimmed = correctAnswer.trim();
  
  // Exact string match (case-insensitive, whitespace-normalized)
  if (userTrimmed.toLowerCase().replace(/\s+/g, '') === 
      correctTrimmed.toLowerCase().replace(/\s+/g, '')) {
    return true;
  }
  
  // Handle multiple acceptable answers separated by " or "
  const acceptableAnswers = correctTrimmed.split(/\s+or\s+/i);
  
  for (const acceptable of acceptableAnswers) {
    // Try exact match with this variant
    if (userTrimmed.toLowerCase().replace(/\s+/g, '') === 
        acceptable.toLowerCase().replace(/\s+/g, '')) {
      return true;
    }
    
    // Try numeric evaluation
    const userValue = tryEvaluate(userTrimmed);
    const acceptableValue = tryEvaluate(acceptable);
    
    if (userValue !== null && acceptableValue !== null) {
      // Allow small relative error (0.01%) for floating point comparison
      const tolerance = Math.abs(acceptableValue) * 0.0001 + 1e-10;
      if (Math.abs(userValue - acceptableValue) <= tolerance) {
        return true;
      }
    }
  }
  
  // Special case: try to match common equivalent forms
  // e.g., "1/2" and "0.5", "sqrt(2)" and "1.414..."
  const userValue = tryEvaluate(userTrimmed);
  
  if (userValue !== null) {
    for (const acceptable of acceptableAnswers) {
      const acceptableValue = tryEvaluate(acceptable);
      
      if (acceptableValue !== null) {
        const tolerance = Math.abs(acceptableValue) * 0.0001 + 1e-10;
        if (Math.abs(userValue - acceptableValue) <= tolerance) {
          return true;
        }
      }
    }
  }
  
  return false;
}
