import { Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

export function VersionInfo() {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="text-white hover:bg-white/20 border-transparent"
          data-testid="button-version-info"
        >
          <Info className="h-5 w-5" />
          <span className="sr-only">Version info</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="bg-white/20 backdrop-blur-2xl border-transparent text-white">
        <div className="space-y-1">
          <p className="text-sm font-semibold">Math Practice Pro</p>
          <p className="text-xs">Version 1.01</p>
        </div>
      </PopoverContent>
    </Popover>
  );
}