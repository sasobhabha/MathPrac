import { Badge } from "@/components/ui/badge";
import { Trophy } from "lucide-react";

interface StreakBadgeProps {
  count: number;
}

export function StreakBadge({ count }: StreakBadgeProps) {
  if (count === 0) return null;

  return (
    <Badge variant="secondary" className="gap-1.5 px-3 py-1.5 bg-white/20 text-white border-transparent" data-testid="badge-streak">
      <Trophy className="h-4 w-4" />
      <span className="font-mono font-semibold">{count}</span>
      <span className="text-xs">streak</span>
    </Badge>
  );
}
