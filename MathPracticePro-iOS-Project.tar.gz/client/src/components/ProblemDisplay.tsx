import { Card, CardContent } from "@/components/ui/card";
import { MathDisplay } from "./MathDisplay";
import { Skeleton } from "@/components/ui/skeleton";

interface ProblemDisplayProps {
  problem: string;
  isLoading?: boolean;
}

export function ProblemDisplay({ problem, isLoading = false }: ProblemDisplayProps) {
  if (isLoading) {
    return (
      <Card className="bg-white/20 backdrop-blur-2xl backdrop-saturate-150 border-transparent">
        <CardContent className="p-8">
          <div className="space-y-3">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-5/6" />
            <Skeleton className="h-4 w-4/6" />
            <Skeleton className="h-20 w-full mt-6" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!problem) {
    return (
      <Card className="bg-white/20 backdrop-blur-2xl backdrop-saturate-150 border-transparent">
        <CardContent className="p-12 text-center">
          <p className="text-white text-lg">
            Configure your settings and generate a problem to begin practicing
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/20 backdrop-blur-2xl backdrop-saturate-150 border-transparent">
      <CardContent className="p-8">
        <MathDisplay content={problem} className="text-lg leading-relaxed" data-testid="text-problem" />
      </CardContent>
    </Card>
  );
}
