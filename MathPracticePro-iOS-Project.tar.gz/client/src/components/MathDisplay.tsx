import { useEffect, useRef } from 'react';
import katex from 'katex';

interface MathDisplayProps {
  content: string;
  className?: string;
}

export function MathDisplay({ content, className = '' }: MathDisplayProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const container = containerRef.current;
    container.innerHTML = '';

    const parts = content.split(/(\$\$[\s\S]+?\$\$|\$[^\$]+?\$)/g);

    parts.forEach((part) => {
      if (part.startsWith('$$') && part.endsWith('$$')) {
        const math = part.slice(2, -2);
        const span = document.createElement('div');
        span.className = 'my-4 text-center overflow-x-auto';
        try {
          katex.render(math, span, {
            displayMode: true,
            throwOnError: false,
          });
        } catch (e) {
          span.textContent = part;
        }
        container.appendChild(span);
      } else if (part.startsWith('$') && part.endsWith('$')) {
        const math = part.slice(1, -1);
        const span = document.createElement('span');
        try {
          katex.render(math, span, {
            displayMode: false,
            throwOnError: false,
          });
        } catch (e) {
          span.textContent = part;
        }
        container.appendChild(span);
      } else {
        const lines = part.split('\n');
        lines.forEach((line, idx) => {
          if (line) {
            const textNode = document.createTextNode(line);
            container.appendChild(textNode);
          }
          if (idx < lines.length - 1) {
            container.appendChild(document.createElement('br'));
          }
        });
      }
    });
  }, [content]);

  return <div ref={containerRef} className={`text-white ${className}`} />;
}
