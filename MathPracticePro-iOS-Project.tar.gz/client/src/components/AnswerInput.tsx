import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { CheckCircle2, XCircle } from "lucide-react";

interface AnswerInputProps {
  onSubmit: (answer: string) => void;
  isDisabled?: boolean;
  feedback?: {
    isCorrect: boolean;
    correctAnswer: string;
    explanation: string;
  } | null;
  onNextProblem?: () => void;
}

export function AnswerInput({ 
  onSubmit, 
  isDisabled = false, 
  feedback = null,
  onNextProblem
}: AnswerInputProps) {
  const [answer, setAnswer] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (answer.trim()) {
      onSubmit(answer.trim());
    }
  };

  const handleNext = () => {
    setAnswer("");
    onNextProblem?.();
  };

  if (feedback) {
    return (
      <Card className={`bg-white/20 backdrop-blur-2xl backdrop-saturate-150 border-transparent`}>
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              {feedback.isCorrect ? (
                <>
                  <CheckCircle2 className="h-6 w-6 text-green-400" />
                  <h3 className="text-xl font-semibold text-white">Correct!</h3>
                </>
              ) : (
                <>
                  <XCircle className="h-6 w-6 text-red-400" />
                  <h3 className="text-xl font-semibold text-white">Incorrect</h3>
                </>
              )}
            </div>
            
            {!feedback.isCorrect && (
              <div>
                <p className="text-sm text-white/70">Correct answer:</p>
                <p className="text-lg font-mono font-semibold mt-1 text-white" data-testid="text-correct-answer">
                  {feedback.correctAnswer}
                </p>
              </div>
            )}
            
            <div>
              <p className="text-sm text-white/70 mb-2">Explanation:</p>
              <p className="text-base leading-relaxed text-white" data-testid="text-explanation">
                {feedback.explanation}
              </p>
            </div>

            <Button 
              onClick={handleNext}
              className="w-full border-transparent bg-white/20 hover:bg-white/30 text-white"
              data-testid="button-next-problem"
            >
              Next Problem
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/20 backdrop-blur-2xl backdrop-saturate-150 border-transparent">
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="answer" className="text-sm font-medium text-white">
              Your Answer
            </Label>
            <Input
              id="answer"
              type="text"
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              placeholder="Enter your answer..."
              disabled={isDisabled}
              className="h-12 text-base font-mono bg-white/10 border-transparent text-white placeholder:text-white/50"
              data-testid="input-answer"
              autoComplete="off"
            />
          </div>
          <Button
            type="submit"
            disabled={isDisabled || !answer.trim()}
            className="w-full border-transparent bg-white/20 hover:bg-white/30 text-white"
            data-testid="button-submit-answer"
          >
            Submit Answer
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
