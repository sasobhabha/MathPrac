import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";
import { competitionTypes, topicTypes, type ProblemRequest } from "@shared/schema";

interface ProblemConfigPanelProps {
  onGenerate: (config: ProblemRequest) => void;
  isLoading?: boolean;
}

export function ProblemConfigPanel({ onGenerate, isLoading = false }: ProblemConfigPanelProps) {
  const [competition, setCompetition] = useState<typeof competitionTypes[number]>("AMC 8");
  const [selectedTopics, setSelectedTopics] = useState<typeof topicTypes[number][]>(["Algebra"]);
  const [difficulty, setDifficulty] = useState<number>(5);

  const handleTopicToggle = (topic: typeof topicTypes[number]) => {
    setSelectedTopics((prev) =>
      prev.includes(topic)
        ? prev.filter((t) => t !== topic)
        : [...prev, topic]
    );
  };

  const handleGenerate = () => {
    if (selectedTopics.length === 0) return;
    onGenerate({
      competition,
      topics: selectedTopics,
      difficulty,
    });
  };

  return (
    <Card className="w-full bg-white/20 backdrop-blur-2xl backdrop-saturate-150 border-transparent">
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-4">
        <CardTitle className="text-xl text-white">Problem Settings</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="competition" className="text-sm font-medium text-white">
            Competition
          </Label>
          <Select
            value={competition}
            onValueChange={(value) => setCompetition(value as typeof competitionTypes[number])}
          >
            <SelectTrigger id="competition" data-testid="select-competition" className="bg-white/10 border-transparent text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {competitionTypes.map((comp) => (
                <SelectItem key={comp} value={comp}>
                  {comp}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3">
          <Label className="text-sm font-medium text-white">Topics</Label>
          <div className="space-y-2">
            {topicTypes.map((topic) => (
              <div key={topic} className="flex items-center space-x-2">
                <Checkbox
                  id={topic}
                  checked={selectedTopics.includes(topic)}
                  onCheckedChange={() => handleTopicToggle(topic)}
                  data-testid={`checkbox-topic-${topic.toLowerCase().replace(/\s+/g, '-')}`}
                  className="border-white/30 data-[state=checked]:bg-white data-[state=checked]:border-transparent"
                />
                <Label
                  htmlFor={topic}
                  className="text-sm font-normal cursor-pointer text-white"
                >
                  {topic}
                </Label>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium text-white">Difficulty</Label>
            <span className="text-sm font-mono font-semibold text-white" data-testid="text-difficulty-value">
              {difficulty}
            </span>
          </div>
          <Slider
            value={[difficulty]}
            onValueChange={(value) => setDifficulty(value[0])}
            min={1}
            max={10}
            step={1}
            data-testid="slider-difficulty"
            className="[&_[role=slider]]:border-transparent"
          />
          <div className="flex justify-between text-xs text-white/70">
            <span>Easier</span>
            <span>Harder</span>
          </div>
        </div>

        <Button
          onClick={handleGenerate}
          disabled={isLoading || selectedTopics.length === 0}
          className="w-full border-transparent bg-white/20 hover:bg-white/30 text-white"
          data-testid="button-generate-problem"
        >
          {isLoading ? (
            <>Generating...</>
          ) : (
            <>
              <Sparkles className="mr-2 h-4 w-4" />
              Generate Problem
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
