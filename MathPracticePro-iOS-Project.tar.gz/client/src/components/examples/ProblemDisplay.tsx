import { ProblemDisplay } from '../ProblemDisplay';

export default function ProblemDisplayExample() {
  const sampleProblem = "A square has side length $s$. If the diagonal of the square is $10\\sqrt{2}$, what is the perimeter of the square?\n\n$$d = s\\sqrt{2}$$";
  
  return (
    <div className="max-w-2xl">
      <ProblemDisplay problem={sampleProblem} isLoading={false} />
    </div>
  );
}
