import { AnswerInput } from '../AnswerInput';

export default function AnswerInputExample() {
  return (
    <div className="max-w-2xl space-y-4">
      <AnswerInput
        onSubmit={(answer) => console.log('Submitted answer:', answer)}
        isDisabled={false}
      />
      
      <AnswerInput
        onSubmit={() => {}}
        feedback={{
          isCorrect: true,
          correctAnswer: "40",
          explanation: "Since the diagonal is 10√2 and d = s√2, we have s = 10. The perimeter is 4s = 40."
        }}
        onNextProblem={() => console.log('Next problem')}
      />
    </div>
  );
}
