import { ProblemConfigPanel } from '../ProblemConfigPanel';

export default function ProblemConfigPanelExample() {
  return (
    <ProblemConfigPanel
      onGenerate={(config) => console.log('Generate problem:', config)}
      isLoading={false}
    />
  );
}
