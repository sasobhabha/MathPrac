import { StreakBadge } from '../StreakBadge';

export default function StreakBadgeExample() {
  return (
    <div className="space-y-4">
      <StreakBadge count={0} />
      <StreakBadge count={5} />
      <StreakBadge count={15} />
    </div>
  );
}
