import { MathDisplay } from '../MathDisplay';

export default function MathDisplayExample() {
  const sampleMath = "Find the value of $x$ such that $x^2 + 5x + 6 = 0$. Also consider the equation: $$\\int_0^1 x^2 dx = \\frac{1}{3}$$";
  
  return (
    <div className="p-6 max-w-2xl">
      <MathDisplay content={sampleMath} className="text-lg" />
    </div>
  );
}
