import { useState } from "react";
import { ProblemConfigPanel } from "@/components/ProblemConfigPanel";
import { ProblemDisplay } from "@/components/ProblemDisplay";
import { AnswerInput } from "@/components/AnswerInput";
import { StreakBadge } from "@/components/StreakBadge";
import { VersionInfo } from "@/components/VersionInfo";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { compareMathAnswers } from "@/lib/mathUtils";
import type { ProblemRequest } from "@shared/schema";

export default function Home() {
  const [currentProblem, setCurrentProblem] = useState<string>("");
  const [currentAnswer, setCurrentAnswer] = useState<string>("");
  const [currentExplanation, setCurrentExplanation] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState<{
    isCorrect: boolean;
    correctAnswer: string;
    explanation: string;
  } | null>(null);
  const [streak, setStreak] = useState(0);
  const [problemCount, setProblemCount] = useState(0);
  const { toast } = useToast();

  const handleGenerate = async (config: ProblemRequest) => {
    setIsLoading(true);
    setFeedback(null);
    
    try {
      const response = await fetch("/api/generate-problem", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(config),
      });

      if (!response.ok) {
        throw new Error("Failed to generate problem");
      }

      const data = await response.json();
      setCurrentProblem(data.problem);
      setCurrentAnswer(data.answer);
      setCurrentExplanation(data.explanation);
      setProblemCount(prev => prev + 1);
    } catch (error) {
      console.error("Error generating problem:", error);
      toast({
        title: "Error",
        description: "Failed to generate problem. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitAnswer = (userAnswer: string) => {
    const isCorrect = compareMathAnswers(userAnswer, currentAnswer);
    
    setFeedback({
      isCorrect,
      correctAnswer: currentAnswer,
      explanation: currentExplanation,
    });

    if (isCorrect) {
      setStreak(prev => prev + 1);
    } else {
      setStreak(0);
    }
  };

  const handleNextProblem = () => {
    setFeedback(null);
    setCurrentProblem("");
  };

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-50 bg-white/20 backdrop-blur-2xl backdrop-saturate-150 border-b border-white/10">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold tracking-tight text-white" data-testid="text-app-title">
              Math Practice Pro
            </h1>
            {problemCount > 0 && (
              <Badge variant="outline" className="font-mono text-white border-transparent" data-testid="badge-problem-count">
                Problem #{problemCount}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-3">
            <StreakBadge count={streak} />
            <VersionInfo />
          </div>
        </div>
      </header>

      <main className="container px-4 py-8 md:px-6">
        <div className="mx-auto grid max-w-6xl gap-6 lg:grid-cols-[320px_1fr]">
          <aside className="lg:sticky lg:top-24 lg:h-fit">
            <ProblemConfigPanel 
              onGenerate={handleGenerate}
              isLoading={isLoading}
            />
          </aside>

          <div className="space-y-6">
            <ProblemDisplay 
              problem={currentProblem}
              isLoading={isLoading}
            />

            {currentProblem && !isLoading && (
              <AnswerInput
                onSubmit={handleSubmitAnswer}
                isDisabled={!!feedback}
                feedback={feedback}
                onNextProblem={handleNextProblem}
              />
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
