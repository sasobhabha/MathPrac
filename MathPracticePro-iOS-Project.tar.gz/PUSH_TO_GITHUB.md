# Push iOS App to GitHub

Run these commands in the Replit Shell:

```bash
# 1. Update the remote URL to your repository
git remote set-url origin https://github.com/sasorepo/MathPrac.git

# 2. Add all the new iOS files
git add .

# 3. Commit the changes
git commit -m "Add iOS app support with Capacitor and GitHub Actions"

# 4. Push to GitHub (you may need to authenticate)
git push -u origin main
```

If the branch is named differently (like `master`), use:
```bash
git push -u origin master
```

## After Pushing

1. Go to https://github.com/sasorepo/MathPrac/actions
2. You'll see the "Build iOS App" workflow running
3. Wait for it to complete (takes about 5-10 minutes)
4. Click on the completed workflow run
5. Download the "MathPracticePro-iOS" artifact
6. Extract the zip to get your IPA file
7. Install using TrollStore, Sideloadly, or AltStore (see IOS_BUILD_GUIDE.md)

## Authentication

If GitHub asks for credentials when pushing:
- Username: your GitHub username
- Password: use a Personal Access Token (not your GitHub password)
  - Create one at: https://github.com/settings/tokens
  - Give it "repo" permissions
