import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mathpracticepro.app',
  appName: 'Math Practice Pro',
  webDir: 'dist/public',
  ios: {
    contentInset: 'automatic',
  },
  server: {
    androidScheme: 'https',
    iosScheme: 'https',
  }
};

export default config;
